import schedule
import time
from DALLE import every_day

# Запускаем функцию каждый день в определенное время (например, в 15:00)
schedule.every().day.at("15:00").do(every_day)

# Бесконечный цикл для выполнения расписания
while True:
    schedule.run_pending()
    time.sleep(1)