from openai import OpenAI
from bot import send_image
from random_image import generate_image_prompt

def every_day():
    # Ваш API ключ
    api_key = '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'
    
    # Создаем клиент OpenAI
    client = OpenAI(api_key=api_key)

    # Генерируем случайный промпт для изображения
    prompt = generate_image_prompt()

    # Генерируем изображение с помощью OpenAI DALL·E
    response = client.images.generate(
        model="dall-e-2",
        prompt=prompt,
        size="256x256",
        quality="standard",
        n=1,
    )

    # Получаем URL сгенерированного изображения
    image_url = response.data[0].url

    # Отправляем изображение
    send_image(prompt, image_url)
if __name__ == "__main__":
    every_day()


