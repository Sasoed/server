import telebot
import requests

# Вставьте свой токен Telegram бота
TOKEN = '6874842603:AAF13pxjx6U3Her6kwLzjmvLGS9jiA3kxko'
# Создаем объект бота
bot = telebot.TeleBot(TOKEN)
channel_id = '@gpt_painting'

# Функция для отправки изображения по URL
def send_image(prompt, url):
    try:
        response = requests.get(url)
        if response.status_code == 200: 
            # Отправляем изображение
            bot.send_photo(channel_id, photo=response.content, caption=prompt)
        else:
            print('Не удалось загрузить изображение.')
    except Exception as e:
        print(f'Произошла ошибка: {str(e)}')